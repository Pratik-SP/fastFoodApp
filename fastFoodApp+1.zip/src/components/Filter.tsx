/* eslint-disable react-native/no-inline-styles */
import { FlatList, Platform, Text, TouchableOpacity } from 'react-native';
import { Category } from '../../type';
import { useNavigation, useRoute } from '@react-navigation/native';
import { useEffect, useState } from 'react';
import cn from 'clsx';

type FilterParams = {
  category: string | null;
};

interface FilterProps {
  categories: Category[];
}

function Filter({ categories }: Readonly<FilterProps>) {
  const route = useRoute();
  const navigation = useNavigation();
  const params = route.params as FilterParams;

  const [active, setActive] = useState(params?.category || 'all');

  useEffect(() => {
    const currentCategory = params?.category;

    if (currentCategory) {
      setActive(currentCategory);
    } else {
      setActive('all');
    }
  }, [params?.category]);

  const handlelPress = (id: string) => {
    setActive(id);

    if (id === 'all') navigation.setParams({ category: null } as any);
    else navigation.setParams({ category: id } as any);
  };

  const filterData: (Category | { $id: string; name: string })[] = categories
    ? [{ $id: 'all', name: 'All' }, ...categories]
    : [{ $id: 'all', name: 'All' }];

  return (
    <FlatList
      data={filterData}
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerClassName="gap-x-2 pb-3"
      keyExtractor={item => item.$id}
      renderItem={({ item }) => (
        <TouchableOpacity
          key={item.$id}
          className={cn(
            'filter',
            active === item.$id ? 'bg-amber-500' : 'bg-white',
          )}
          style={
            Platform.OS === 'android'
              ? { elevation: 5, shadowColor: '#878787' }
              : {}
          }
          onPress={() => handlelPress(item.$id)}
        >
          <Text
            className={cn(
              'body-medium',
              active === item.$id ? 'text-white' : 'text-gray-200',
            )}
          >
            {item.name}
          </Text>
        </TouchableOpacity>
      )}
    />
  );
}

export default Filter;
