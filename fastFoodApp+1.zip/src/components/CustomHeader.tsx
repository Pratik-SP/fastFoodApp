import { Image, Text, TouchableOpacity, View } from 'react-native';

import { CustomHeaderProps } from '../../type';
import { images } from '../constants';
import { useNavigation } from '@react-navigation/native';

const CustomHeader = ({ title }: CustomHeaderProps) => {
  const navigation = useNavigation();

  return (
    <View className="custom-header">
      <TouchableOpacity onPress={() => navigation.goBack()}>
        <Image
          source={images.arrowBack}
          className="size-5"
          resizeMode="contain"
        />
      </TouchableOpacity>

      {title && <Text className="base-semibold text-dark-100">{title}</Text>}

      <Image source={images.search} className="size-5" resizeMode="contain" />
    </View>
  );
};

export default CustomHeader;
