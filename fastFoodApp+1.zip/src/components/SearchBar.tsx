/* eslint-disable react-native/no-inline-styles */
import { useState } from 'react';
import {
  Image,
  Platform,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import {
  NavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { images } from '../constants';

type RootStackParamList = {
  Search: { query?: string };
};

type SearchScreenRouteProp = RouteProp<RootStackParamList, 'Search'>;
type SearchScreenNavigationProp = NavigationProp<RootStackParamList, 'Search'>;

function SearchBar() {
  const navigation = useNavigation<SearchScreenNavigationProp>();
  const route = useRoute<SearchScreenRouteProp>();
  const [query, setQuery] = useState(route.params?.query || '');

  const handleSearch = (text: string) => {
    setQuery(text);

    if (!text) navigation.setParams({ query: undefined });
  };

  const handleSubmit = () => {
    if (query.trim()) navigation.setParams({ query });
  };
  return (
    <View
      className="searchbar"
      style={
        Platform.OS === 'android'
          ? { elevation: 5, shadowColor: '#878787' }
          : {}
      }
    >
      <TextInput
        className="flex-1 p-5"
        placeholder="Search for your favorite food item"
        value={query}
        onChangeText={handleSearch}
        onSubmitEditing={handleSubmit}
        placeholderTextColor="#A0A0A0"
        returnKeyType="search"
      />
      <TouchableOpacity
        className="pr-5"
        onPress={() => navigation.setParams({ query })}
      >
        <Image
          source={images.search}
          className="size-6"
          resizeMode="contain"
          tintColor="#5D5F6D"
        />
      </TouchableOpacity>
    </View>
  );
}

export default SearchBar;
