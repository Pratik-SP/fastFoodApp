import { createNativeStackNavigator } from '@react-navigation/native-stack';

import TabsNavigator from './(tabs)/TabsNavigator';
import AuthNavigator from './(auth)/AuthNavigator';
import useAuthStore from '../store/auth.store';

const Stack = createNativeStackNavigator();
function RootNavigator() {
  const { isAuthenticated } = useAuthStore();

  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      {isAuthenticated ? (
        <Stack.Screen name="Tabs" component={TabsNavigator} />
      ) : (
        <Stack.Screen name="Auth" component={AuthNavigator} />
      )}
    </Stack.Navigator>
  );
}

export default RootNavigator;
