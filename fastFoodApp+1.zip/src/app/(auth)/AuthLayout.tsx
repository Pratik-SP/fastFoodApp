/* eslint-disable react-native/no-inline-styles */
import {
  Dimensions,
  Image,
  ImageBackground,
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  View,
} from 'react-native';
import { ReactNode, useEffect, useRef } from 'react';
import { images } from '../../constants';

type AuthLayoutProps = {
  children: ReactNode;
};

function AuthLayout({ children }: Readonly<AuthLayoutProps> | any) {
  const scrollViewRef = useRef<ScrollView>(null);
  const currentInputRef = useRef<any>(null);

  useEffect(() => {
    const keyboardDidShowListener = Keyboard.addListener(
      'keyboardDidShow',
      event => {
        if (currentInputRef.current && scrollViewRef.current) {
          setTimeout(() => {
            currentInputRef.current?.measure(
              (
                x: number,
                y: number,
                width: number,
                height: number,
                pageX: number,
                pageY: number,
              ) => {
                const keyboardHeight = event.endCoordinates.height + 100;
                const screenHeight = Dimensions.get('window').height;
                const inputBottomY = pageY + height;
                const visibleScreenHeight = screenHeight - keyboardHeight;

                if (inputBottomY > visibleScreenHeight) {
                  const scrollOffset = inputBottomY - visibleScreenHeight + 20;
                  scrollViewRef.current?.scrollTo({
                    y: scrollOffset,
                    animated: true,
                  });
                }
              },
            );
          }, 100);
        }
      },
    );

    const keyboardDidHideListener = Keyboard.addListener(
      'keyboardDidHide',
      () => {
        scrollViewRef.current?.scrollTo({ y: 0, animated: true });
      },
    );

    return () => {
      keyboardDidShowListener.remove();
      keyboardDidHideListener.remove();
    };
  }, []);

  const onInputFocus = (inputRef: any) => {
    currentInputRef.current = inputRef;
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, paddingBottom: 50 }}
      behavior={Platform.OS === 'android' ? 'height' : 'padding'}
    >
      <ScrollView
        ref={scrollViewRef}
        className="bg-white"
        contentContainerStyle={{ minHeight: Dimensions.get('window').height }}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <View
          className="w-full relative"
          style={{ height: Dimensions.get('screen').height / 2.5 }}
        >
          <ImageBackground
            source={images.loginGraphic}
            className="size-full rounded-b-lg"
            resizeMode="stretch"
          />

          <Image
            source={images.logo}
            className="self-center size-48 absolute -bottom-16 z-10"
          />
        </View>
        <View className="flex-1">
          {typeof children === 'function'
            ? children({ onInputFocus })
            : children}
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
export default AuthLayout;
