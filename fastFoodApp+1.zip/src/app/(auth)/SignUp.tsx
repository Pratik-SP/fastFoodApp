import { Alert, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useRef, useState } from 'react';

import { createUser, getCurrentUser } from '../lib/appwrite';
import useAuthStore from '../../store/auth.store';
import CustomInput from '../../components/CustomInput';
import CustomButton from '../../components/CustomButton';
import { AuthStackParamList } from '../../../type';

type AuthNavProp = NativeStackNavigationProp<AuthStackParamList>;

type FormProps = {
  onInputFocus?: (inputRef: any) => void;
};

function SignUp({ onInputFocus }: Readonly<FormProps>) {
  const nameRef = useRef<TextInput>(null);
  const emailRef = useRef<TextInput>(null);
  const passwordRef = useRef<TextInput>(null);

  const AuthNavigation = useNavigation<AuthNavProp>();
  const { setIsAuthenticated, setUser } = useAuthStore();

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', password: '' });

  const handleNameFocus = () => onInputFocus?.(nameRef.current);
  const handleEmailFocus = () => onInputFocus?.(emailRef.current);
  const handlePasswordFocus = () => onInputFocus?.(passwordRef.current);

  const submit = async () => {
    const { name, email, password } = form;
    if (!name || !email || !password)
      return Alert.alert('Error', 'Please Enter a valid email & password!');

    setIsSubmitting(true);
    try {
      await createUser({ name, email, password });

      const user = await getCurrentUser();
      if (user) {
        setUser(user as any);
        setIsAuthenticated(true);
      }
    } catch (error: any) {
      Alert.alert('Error', error.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <View className="gap-10 bg-white rounded-lg p-5 mt-5">
      <CustomInput
        ref={nameRef}
        placeholder="Enter your name"
        value={form.name}
        onChangeText={text => setForm(prev => ({ ...prev, name: text }))}
        label="Name"
        keyboardType="default"
        onFocus={handleNameFocus}
      />

      <CustomInput
        ref={emailRef}
        placeholder="Enter your email"
        value={form.email}
        onChangeText={text => setForm(prev => ({ ...prev, email: text }))}
        label="Email"
        keyboardType="email-address"
        onFocus={handleEmailFocus}
      />

      <CustomInput
        ref={passwordRef}
        placeholder="Enter your Password"
        value={form.password}
        onChangeText={text => setForm(prev => ({ ...prev, password: text }))}
        label="Password"
        secureTextEntry={true}
        onFocus={handlePasswordFocus}
      />

      <CustomButton isLoading={isSubmitting} onPress={submit} title="Sign Up" />

      <View className="flex justify-center flex-row gap-2">
        <Text className="base-regular text-gray-100">
          Already have an account?
        </Text>
        <TouchableOpacity onPress={() => AuthNavigation.navigate('SignIn')}>
          <Text className="base-bold text-primary">Sign In</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

export default SignUp;
