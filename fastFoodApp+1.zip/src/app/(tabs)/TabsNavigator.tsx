/* eslint-disable react/no-unstable-nested-components */
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { View } from 'react-native';

import IndexScreen from './Index';
import ProfileScreen from './Profile';
import SearchScreen from './Search';
import CartScreen from './Cart';
import { images } from '../../constants';
import TabBarIcon from '../../components/TabBarIcon';

const Tab = createBottomTabNavigator();
function TabsNavigator() {
  return (
    <View className="flex-1 bg-white">
      <Tab.Navigator
        screenOptions={{
          headerShown: false,
          tabBarShowLabel: false,
          tabBarStyle: {
            borderTopLeftRadius: 50,
            borderTopRightRadius: 50,
            borderBottomLeftRadius: 50,
            borderBottomRightRadius: 50,
            marginHorizontal: 20,
            height: 80,
            position: 'absolute',
            bottom: 10,
            backgroundColor: 'white',
            shadowColor: '#1a1a1a',
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.1,
            shadowRadius: 4,
            elevation: 5,
          },
        }}
      >
        <Tab.Screen
          name="Index"
          options={{
            title: 'Home',
            tabBarIcon: ({ focused }) => (
              <TabBarIcon title="Home" icon={images.home} focused={focused} />
            ),
          }}
          component={IndexScreen}
        />

        <Tab.Screen
          name="Search"
          options={{
            title: 'Search',
            tabBarIcon: ({ focused }) => (
              <TabBarIcon
                title="Search"
                icon={images.search}
                focused={focused}
              />
            ),
          }}
          component={SearchScreen}
        />

        <Tab.Screen
          name="Cart"
          options={{
            title: 'Cart',
            tabBarIcon: ({ focused }) => (
              <TabBarIcon title="Cart" icon={images.bag} focused={focused} />
            ),
          }}
          component={CartScreen}
        />

        <Tab.Screen
          name="Profile"
          options={{
            title: 'Profile',
            tabBarIcon: ({ focused }) => (
              <TabBarIcon
                title="Profile"
                icon={images.person}
                focused={focused}
              />
            ),
          }}
          component={ProfileScreen}
        />
      </Tab.Navigator>
    </View>
  );
}

export default TabsNavigator;
