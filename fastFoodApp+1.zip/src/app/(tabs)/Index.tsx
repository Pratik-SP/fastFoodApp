// /* eslint-disable @typescript-eslint/no-unused-vars */
import { FlatList, Image, Text, TouchableOpacity, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import cn from 'clsx';

import { images, offers } from '../../constants';
import CartButton from '../../components/CartButton';
import { useNavigation } from '@react-navigation/native';
import { TabStackParamList } from '../../../type';
import { BottomTabNavigationProp } from '@react-navigation/bottom-tabs';
import useAuthStore from '../../store/auth.store';

function ListHeader() {
  return (
    <View className="flex-between flex-row w-full my-5 px-5">
      <View className="flex-start">
        <Text className="small-bold text-primary">DELIVER TO</Text>
        <TouchableOpacity className="flex-center flex-row gap-x-1 mt-0.5">
          <Text className="paragraph-bold text-dark-100">Gujarat</Text>
          <Image
            source={images.arrowDown}
            className="size-3"
            resizeMode="contain"
          />
        </TouchableOpacity>
      </View>

      <CartButton />
    </View>
  );
}

type TabNavProp = BottomTabNavigationProp<TabStackParamList>;

function Index() {
  const { user } = useAuthStore();
  const navigation = useNavigation<TabNavProp>();

  console.log(user);
  return (
    <SafeAreaView className="flex-1 bg-white">
      <FlatList
        data={offers}
        renderItem={({ item, index }) => {
          const isEven = index % 2 === 0;
          return (
            <View>
              <TouchableOpacity
                activeOpacity={0.9}
                className={cn(
                  'offer-card',
                  isEven ? 'flex-row-reverse' : 'flex-row',
                )}
                style={{ backgroundColor: item.color }}
                onPress={() =>
                  navigation.navigate('Search', {
                    category: item.categories[0],
                  })
                }
              >
                <View className="h-full w-1/2">
                  <Image
                    source={item.image}
                    className={'size-full'}
                    resizeMode={'contain'}
                  />
                </View>
                <View
                  className={cn('offer-card__info', isEven ? 'pl-10' : 'pr-10')}
                >
                  <Text className="h1-bold text-white leading-tight">
                    {item.title}
                  </Text>
                  <Image
                    source={images.arrowRight}
                    className="size-10"
                    resizeMode="contain"
                    tintColor="#ffffff"
                  />
                </View>
              </TouchableOpacity>
            </View>
          );
        }}
        contentContainerClassName="pb-28 px-5"
        ListHeaderComponent={ListHeader}
      />
    </SafeAreaView>
  );
}

export default Index;
