import { Image, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { signOut } from '../lib/appwrite';
import useAuthStore from '../../store/auth.store';
import { images } from '../../constants';
import CustomHeader from '../../components/CustomHeader';
import CustomButton from '../../components/CustomButton';

function ProfileDetails({ title, userDetail, image }: any) {
  return (
    <View className="profile-field pt-4">
      <View className="profile-field__icon">
        <Image source={image} className="size-12" resizeMode="center" />
      </View>
      <View className="flex-1 py-1">
        <Text className="label">{title}</Text>
        <Text className="label paragraph-semibold">{userDetail}</Text>
      </View>
    </View>
  );
}

function Profile() {
  const { setIsAuthenticated, setUser, user } = useAuthStore();
  const handleLogout = async () => {
    try {
      await signOut();

      setIsAuthenticated(false);
      setUser(null);
    } catch (error) {
      console.error('Logout error', error);
    }
  };
  return (
    <SafeAreaView className="flex-1">
      <View className="px-5 pt-5">
        <CustomHeader title="Profile" />
        <View className="py-8 flex-center">
          <Image source={{ uri: user?.avatar }} className="profile-avatar" />
          <View className="ml-20">
            <Image
              source={images.pencil}
              resizeMode="center"
              className="profile-edit"
            />
          </View>
          <Text className="h3-bold mt-4">{user?.name}</Text>
        </View>

        <View className="p-4 bg-white rounded-lg">
          <ProfileDetails
            title="Name"
            userDetail={user?.name}
            image={images.user}
          />
          <ProfileDetails
            title="Email"
            userDetail={user?.email}
            image={images.envelope}
          />
          {/* <ProfileDetails title="Name" userDetail={user?.name} /> */}
          {/* <ProfileDetails title="Name" userDetail={user?.name} /> */}
        </View>

        <CustomButton title="Sign Out" onPress={handleLogout} />
      </View>
    </SafeAreaView>
  );
}
export default Profile;
