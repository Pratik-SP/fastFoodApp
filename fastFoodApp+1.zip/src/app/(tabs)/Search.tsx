import { ActivityIndicator, FlatList, Text, View } from 'react-native';
import { useEffect } from 'react';
import { SafeAreaView } from 'react-native-safe-area-context';
import { RouteProp, useRoute } from '@react-navigation/native';
import cn from 'clsx';

import { getCategories, getMenu } from '../lib/appwrite';
import useAppwrite from '../lib/useAppwirte';
import CartButton from '../../components/CartButton';
import MenuCard from '../../components/MenuCard';
import { Category, MenuItem, TabStackParamList } from '../../../type';
import SearchBar from '../../components/SearchBar';
import Filter from '../../components/Filter';

type SearchScreenRouteProp = RouteProp<TabStackParamList, 'Search'>;

function Search() {
  const route = useRoute<SearchScreenRouteProp>();
  const { query = '', category = '' } = route.params ?? {};
  console.log('Fetching menu with:', { category, query });

  const {
    data: menuItems,
    refetch,
    loading: menuLoading,
  } = useAppwrite({
    fn: getMenu,
    params: { category, query, limit: 6 },
  });

  const { data: rawCategories, loading: categoriesLoading } = useAppwrite({
    fn: getCategories,
  });

  const categories: Category[] | undefined = rawCategories?.map(doc => ({
    $id: doc.$id,
    name: doc.name,
    description: doc.description,
  }));

  useEffect(() => {
    refetch({ category, query, limit: 6 });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [category, query]);

  return (
    <SafeAreaView className="bg-white h-full">
      <FlatList
        data={menuItems}
        renderItem={({ item, index }) => {
          const isFirstRightColItem = index % 2 === 0;

          return (
            <View
              className={cn(
                'flex-1 max-w-[48%]',
                !isFirstRightColItem ? 'mt-10' : 'mt-0',
              )}
            >
              <MenuCard item={item as unknown as MenuItem} />
            </View>
          );
        }}
        keyExtractor={item => item.$id}
        numColumns={2}
        columnWrapperClassName="gap-7"
        contentContainerClassName="gap-7 px-5 pb-32"
        // eslint-disable-next-line react/no-unstable-nested-components
        ListHeaderComponent={() => (
          <View className="my-5 gap-5">
            <View className="flex-between flex-row w-full">
              <View className="flex-start">
                <Text className="small-bold uppercase text-primary">
                  Search
                </Text>
                <View className="flex-start flex-row gap-x-1 mt-0.5">
                  <Text className="paragraph-semibold text-dark-100">
                    Find your favorite food
                  </Text>
                </View>
              </View>

              <CartButton />
            </View>

            <SearchBar />
            {!categoriesLoading && <Filter categories={categories!} />}
          </View>
        )}
        // eslint-disable-next-line react/no-unstable-nested-components
        ListEmptyComponent={() => (
          <View className="flex-1 flex-center">
            {menuLoading ? (
              <>
                <ActivityIndicator size="large" color="#FE8C00" />
                <Text className="paragraph-semibold text-primary">
                  Fetching menu items
                </Text>
              </>
            ) : (
              <Text className="paragraph-semibold text-dark-200">
                No results found.
              </Text>
            )}
          </View>
        )}
      />
    </SafeAreaView>
  );
}

export default Search;
